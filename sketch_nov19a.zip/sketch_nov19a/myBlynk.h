#define BLYNK_TEMPLATE_ID "TMPL3YVHL705q"
#define BLYNK_TEMPLATE_NAME "Solar Energy"
#define BLYNK_AUTH_TOKEN "kWOy0w-gQq1vdvvyfpk-FPzvdOisVT7T"

/* Comment this out to disable prints and save space */
#define BLYNK_PRINT Serial

#include <ESP8266WiFi.h>
#include <BlynkSimpleEsp8266.h>

// Your WiFi credentials.
char ssid[] = "Airtel_manj_7525";
char pass[] = "air85096";

void myBlynk_initialise()
{
  // Connect to Blynk server
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
}
